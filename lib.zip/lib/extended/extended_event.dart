part of 'extended_bloc.dart';

final class CustomExtendedEvent extends CCBaseEvent {
  const CustomExtendedEvent({required this.eventProp});
  final String eventProp;
}
